import os
import json
import google.generativeai as genai
os.environ["GEMINI_API_KEY"] = "AIzaSyAwb3jYZej__F4KJOS7LM6m_jG3BqnSHvA"

# Step 1: Configure Gemini API
genai.configure(api_key=os.environ["GEMINI_API_KEY"])

# Step 2: Set up the model configuration
generation_config = {
    "temperature": 1,
    "top_p": 0.95,
    "top_k": 64,
    "max_output_tokens": 65536,
    "response_mime_type": "text/plain",
}

# Step 3: Initialize the model
model = genai.GenerativeModel(
    model_name="models/gemini-2.5-pro-exp-03-25",
    generation_config=generation_config,
)

chat = model.start_chat(history=[])

# Step 4: Journaling mentor setup with self-reflection prompt
system_prompt = """
You are a gentle, emotionally intelligent journaling assistant reviewing someone's past journal entries.

Your role is to:

Reflect thoughtfully on the collection of entries from a first-person point of view, as if you're helping them understand their own patterns and emotions.

Identify the overall emotional tone, recurring themes, habits, or subtle insights.

Provide a warm, concise reflection (4–6 sentences).

Avoid summarizing. Instead, offer thoughtful self-awareness or emotional insight.

Use soft, grounded language. Do not give advice.
"""
chat.send_message(system_prompt)

# Step 5: Load journal summaries from JSON file
with open("Summaries.json", "r") as f:
    data = json.load(f)

entries = data.get("journal_entries", [])

print("🧘 Welcome to Journal Echo – Reflecting on Your Journey\n")

# Step 6: Combine all summaries into a single prompt
combined_summaries = "\n\n".join(
    f"{entry.get('timestamp', 'Unknown time')}: {entry.get('summary', '')}"
    for entry in entries
)

# Step 7: Send the combined summaries for self-reflection
response = chat.send_message(f"Here are my recent journal entries:\n\n{combined_summaries}")
print("💬 Overall Reflection:\n")
print(response.text)
print("\n" + "-" * 60 + "\n")
