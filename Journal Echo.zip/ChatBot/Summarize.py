import os
import json
import google.generativeai as genai

# Configure Gemini API
os.environ["GEMINI_API_KEY"] = "AIzaSyCL82Oq_JHB3dVijRlPjCmFWghRkR0ySl4"
genai.configure(api_key=os.environ["GEMINI_API_KEY"])

# Load Gemini model
model = genai.GenerativeModel(
    model_name="models/gemini-2.5-pro-exp-03-25",
    generation_config={
        "temperature": 1,
        "top_p": 0.95,
        "top_k": 64,
        "max_output_tokens": 65536,
        "response_mime_type": "text/plain",
    },
)

# Load the journal entries
with open("journal_entries.json", "r") as f:
    journal_data = json.load(f)

# Get the last session
latest_session = journal_data[-1]
timestamp = latest_session["session_timestamp"]
entries = latest_session["entries"]

# Combine the session into plain text
combined_text = "\n".join(
    f"{entry['timestamp']} - You: {entry['user_input']}" for entry in entries
)

# System prompt for summarization
system_prompt = """
You are a journaling assistant. Summarize the user's full journaling session.

Include:
- Important events and dates
- The emotional tone and how it changed
- Observations about the user's personality and emotional state

Keep it short (4-6 lines). Write in a friendly, human tone.

Output only the summary text. Do NOT include any JSON formatting or labels.
"""

# Generate summary using Gemini
chat = model.start_chat()
chat.send_message(system_prompt)
response = chat.send_message(combined_text)

# Get the summary from the response
summary_text = response.text.strip()

# Format the final summary entry
summary_entry = {
    "timestamp": timestamp,
    "summary": summary_text
}

# Save to Summaries.json
summary_path = "Summaries.json"

# Load existing summaries with proper structure handling
summaries_data = {"journal_entries": []}
if os.path.exists(summary_path):
    try:
        with open(summary_path, "r") as f:
            file_content = f.read().strip()
            if file_content:  # Check if file is not empty
                data = json.loads(file_content)
                
                # Check if the data has the expected structure
                if isinstance(data, dict) and "journal_entries" in data:
                    summaries_data = data
                else:
                    # If structure doesn't match, initialize with correct structure
                    # and attempt to incorporate existing data if it's in a compatible format
                    print("Warning: Existing file doesn't have the expected structure")
                    if isinstance(data, list):
                        # If it's a list, assume these are entries
                        summaries_data["journal_entries"] = data
                    elif isinstance(data, dict):
                        # If it's some other dict structure, start fresh
                        print("Unable to use existing data structure - creating new format")
    except Exception as e:
        print(f"Error loading existing summaries: {e}")
        print("Creating a new summaries file with correct structure.")

# Add the new summary to the journal_entries array
summaries_data["journal_entries"].append(summary_entry)

# Save the updated summaries
with open(summary_path, "w") as f:
    json.dump(summaries_data, f, indent=2)

print(f"✅ Summary added to {summary_path}")
print(f"Total summaries now: {len(summaries_data['journal_entries'])}")