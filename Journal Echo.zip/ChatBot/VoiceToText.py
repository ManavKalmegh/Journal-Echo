import os
import sounddevice as sd
import queue
import vosk

# Set up a queue for real-time speech processing
q = queue.Queue()

# Parameters for audio input
samplerate = 16000
duration = 5  # Duration to record at a time

# Load the Vosk model (download model from https://alphacephei.com/vosk/models)
model = vosk.Model("model")  # Replace "model" with your model path

# Set up the recognizer
recognizer = vosk.KaldiRecognizer(model, samplerate)

# Callback function for recording audio in real-time
def callback(indata, frames, time, status):
    if status:
        print(status, flush=True)
    q.put(bytes(indata))

# Set up the audio stream
stream = sd.InputStream(callback=callback, channels=1, samplerate=samplerate)
stream.start()

print("Speak Now!")

while True:
    data = q.get()
    if recognizer.AcceptWaveform(data):
        result = recognizer.Result()
        print("Recognized: ", result)

# Press Ctrl+C to stop the program
