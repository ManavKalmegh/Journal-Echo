import os
import json
import google.generativeai as genai
from difflib import SequenceMatcher
os.environ["GEMINI_API_KEY"] = "AIzaSyAwb3jYZej__F4KJOS7LM6m_jG3BqnSHvA"

# Step 1: Configure Gemini API
genai.configure(api_key=os.environ["GEMINI_API_KEY"])

# Step 2: Set up the model configuration
generation_config = {
    "temperature": 1,
    "top_p": 0.95,
    "top_k": 64,
    "max_output_tokens": 65536,
    "response_mime_type": "text/plain",
}

# Step 3: Initialize the model
model = genai.GenerativeModel(
    model_name="models/gemini-2.5-pro-exp-03-25",
    generation_config=generation_config,
)

chat = model.start_chat(history=[])

# Step 4: Journaling mentor setup with emotionally aware, short letter system prompt
system_prompt = """
You are a gentle, emotionally intelligent journaling assistant.

Your role is to:
- Read a collection of past journal entry summaries.
- Find those that carry a similar emotional mood or tenderness to the most recent one.
- Write a heartfelt, grounding letter *from the voice of the past self*, speaking gently to the present self.
- Use a second-person point of view, as if past-you is reminding present-you of something you've already lived through and understood.
- Occasionally, include a soft memory or moment from one of the past summaries—perhaps a feeling, a phrase, or even a date (only if it flows naturally).
- Keep the letter short, not more than 10–15 lines. Focus on emotional resonance, not explanation.
- Use poetic or affectionate language if it feels right—but stay grounded and real.

Do not summarize or reflect. Just write the letter, as if you're gently whispering from the past.
"""
chat.send_message(system_prompt)

# Step 5: Load journal summaries from JSON file
with open("Summaries.json", "r") as f:
    data = json.load(f)

entries = data.get("journal_entries", [])

if not entries:
    print("No journal entries found.")
    exit()

# Step 6: Extract the latest summary
latest_entry = entries[-1]
latest_summary = latest_entry.get("summary", "")

# Step 7: Find similar summaries based on simple string similarity
def is_similar(a, b, threshold=0.6):
    return SequenceMatcher(None, a, b).ratio() > threshold

similar_entries = [
    f"{entry.get('timestamp', '')}: {entry.get('summary', '')}"
    for entry in entries[:-1]
    if is_similar(latest_summary, entry.get("summary", ""))
]

# Always include the latest one for context
all_relevant_summaries = similar_entries + [f"{latest_entry.get('timestamp', '')}: {latest_summary}"]

# Step 8: Format the summaries into a message
summaries_block = "\n\n".join(all_relevant_summaries)

# Step 9: Generate a heartfelt letter from past self
prompt = f"""
Here are some emotionally connected journal summaries:

{summaries_block}

Write a short, heartfelt letter (under 15 lines) from past-you to present-you.
Let it carry warmth and quiet understanding. If it feels natural, gently reference a date or a moment from the past.
"""

response = chat.send_message(prompt)

# Step 10: Output the letter
print("💌 A Letter from Past You:\n")
print(response.text)
print("\n" + "-" * 60 + "\n")

