import json
from datetime import datetime
import google.generativeai as genai  # ✅ Add this
import os

# 🔐 TEMPORARY: Directly set your API key here
genai.configure(api_key="AIzaSyAwb3jYZej__F4KJOS7LM6m_jG3BqnSHvA")

# 🧠 Gemini chat setup
generation_config = {
    "temperature": 1,
    "top_p": 0.95,
    "top_k": 64,
    "max_output_tokens": 65536,
    "response_mime_type": "text/plain",
}

model = genai.GenerativeModel(
    model_name="models/gemini-1.5-pro-latest",
    generation_config=generation_config,
)

chat = model.start_chat(history=[])


def get_latest_summary(file_path):
    try:
        with open(file_path, 'r') as file:
            data = json.load(file)

            if not isinstance(data, list) or not data:
                print("Data is not a list or is empty.")
                return None

            def parse_timestamp(entry):
                try:
                    return datetime.fromisoformat(entry['timestamp'].replace("Z", "+00:00"))
                except (KeyError, ValueError):
                    return datetime.min

            latest_entry = max(data, key=parse_timestamp)
            return latest_entry

    except Exception as e:
        print(f"Error reading summary: {e}")
        return None
    
def generate_empathetic_response(summary_entry, chat):
    if not summary_entry:
        return "I'm here whenever you're ready to share your thoughts."

    summary = summary_entry.get("summary", "")
    
    user_prompt = f"""
This is the user's journal summary:
"{summary}"

You are a warm, emotionally intelligent friend.

Your job is to:
- Read the journal summary shared by the user.
- Remember the important incidents and also include them in your repsonse 
- Understand what they’re feeling based on what they’ve been through.
- Respond in a brief, kind, and human way — like a close friend would.
- If they seem sad, be extra gentle and comforting.
- If they’re happy, celebrate with them and feel free to joke or be playful.
- End your response with a soft question or invitation to share more if necessary.

Make the user feel safe, seen, and emotionally supported.
Keep things light and friendly — no lecturing, no deep analysis, and definitely no judgment.

Think like a mix of: a close friend, a safe space, and someone who just gets them.
"""

    response = chat.send_message(user_prompt)
    return response.text.strip()

# Load latest summary and create chat
summary_entry = get_latest_summary("Summaries.json")
empathetic_response = generate_empathetic_response(summary_entry, chat)


print("🧘 Welcome to Journal Echo – Your Journaling chat\n(Type 'exit' to end the session)\n")
print(f"CHATBOT: {empathetic_response}\n")

# Now begin journaling chat loop
while True:
    user_input = input("You: ")
    if not user_input:
        continue
    if user_input.lower() in ["exit", "quit"]:
        print("\n📔 Journaling session ended. Take care of yourself.")
        break

    response = chat.send_message(user_input)
    print(f"Mentor: {response.text.strip()}\n")